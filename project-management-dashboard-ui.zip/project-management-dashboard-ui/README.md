# Project Management Dashboard UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/aybukeceylan/pen/OJRNbZp](https://codepen.io/aybukeceylan/pen/OJRNbZp).

https://dribbble.com/shots/14038313-Project-Management-Dashboard-UX-UI-Design